class Address:

    def __init__(self, city:str, state:str, pincode:int):
        self.city = city
        self.state = state
        self.pincode = pincode